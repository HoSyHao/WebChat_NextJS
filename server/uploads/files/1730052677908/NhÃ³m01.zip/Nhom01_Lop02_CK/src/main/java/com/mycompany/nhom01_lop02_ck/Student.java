/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nhom01_lop02_ck;

/**
 *
 * @author blood
 */
public class Student {
    
    private String name;
    private int age;
    private double grade;

    // Constructor có tham số: có xử lý data
    public Student(String name, int age, double grade) {
        this.name = validateName(name);
        this.age = validateAge(age);
        this.grade = validateGrade(grade);
    }

    // Getters và setters: có xử lý data
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = validateName(name);
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = validateAge(age);
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = validateGrade(grade);
    }

    // Phương thức xử lý dữ liệu (private)
    private String validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Tên không được để trống");
        }
        return name.trim();
    }

    private int validateAge(int age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("Tuổi không hợp lệ");
        }
        return age;
    }

    private double validateGrade(double grade) {
        if (grade < 0.0 || grade > 10.0) {
            throw new IllegalArgumentException("Điểm không hợp lệ");
        }
        return grade;
    }

    // Phương thức void
    public void printStudentInfo() {
        System.out.println("Tên: " + name);
        System.out.println("Tuổi: " + age);
        System.out.println("Điểm: " + grade);
    }

    // Phương thức có kiểu trả về
    public boolean isPassed() {
        return grade >= 5.0;
    }

    // Phương thức có xử lý Exception
    public void updateGrade(double newGrade) {
        try {
            setGrade(newGrade);
            System.out.println("Cập nhật điểm thành công.");
        } catch (IllegalArgumentException e) {
            System.out.println("Lỗi khi cập nhật điểm: " + e.getMessage());
        }
    }
}


