/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nhom01_lop02_ck;

/**
 *
 * @author blood
 */
public class Actor {
    // Thuộc tính (biến instance)
    private String name;
    private int age;
    private double rating;

    // Constructor có tham số: có xử lý data
    public Actor(String name, int age, double rating) {
        this.name = validateName(name);
        this.age = validateAge(age);
        this.rating = validateRating(rating);
    }

    // Getters và setters: có xử lý data
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = validateName(name);
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = validateAge(age);
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = validateRating(rating);
    }

    // Phương thức xử lý dữ liệu (private)
    private String validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Tên diễn viên không được để trống");
        }
        return name.trim();
    }

    private int validateAge(int age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("Tuổi không hợp lệ");
        }
        return age;
    }

    private double validateRating(double rating) {
        if (rating < 0.0 || rating > 10.0) {
            throw new IllegalArgumentException("Điểm đánh giá không hợp lệ");
        }
        return rating;
    }

    // Phương thức void
    public void printActorInfo() {
        System.out.println("Tên diễn viên: " + name);
        System.out.println("Tuổi: " + age);
        System.out.println("Điểm đánh giá: " + rating);
    }

    // Phương thức có kiểu trả về
    public boolean isTopRated() {
        return rating >= 8.0; // Nếu điểm đánh giá từ 8.0 trở lên thì được xem là top-rated
    }

    // Phương thức có xử lý Exception
    public void updateRating(double newRating) {
        try {
            setRating(newRating);
            System.out.println("Cập nhật điểm đánh giá thành công.");
        } catch (IllegalArgumentException e) {
            System.out.println("Lỗi khi cập nhật điểm đánh giá: " + e.getMessage());
        }
    }
    
    
}

