/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nhom01_lop02_ck;

/**
 *
 * @author blood
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
