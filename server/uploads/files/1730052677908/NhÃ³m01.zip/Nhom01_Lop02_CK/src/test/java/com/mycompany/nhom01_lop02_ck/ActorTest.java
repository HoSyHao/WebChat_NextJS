import com.mycompany.nhom01_lop02_ck.Actor;
import org.junit.Test;
import static org.junit.Assert.*;

public class ActorTest {

    private Actor instance;

    public ActorTest() {
        // Khởi tạo đối tượng Actor với các giá trị mặc định
        instance = new Actor("John Doe", 30, 8.0);
    }

    /**
     * Test of updateRating method, of class Actor.
     */
    @Test
    public void testUpdateRating_ValidRating() {
        double newRating = 9.0;
        instance.updateRating(newRating);
        assertEquals(9.0, instance.getRating(), 0.001);
    }

    @Test
    public void testUpdateRating_InvalidRatingNegative() {
        double newRating = -1.0;
        try {
            instance.updateRating(newRating);
            fail("Expected IllegalArgumentException for negative rating");
        } catch (IllegalArgumentException e) {
            assertEquals("Điểm đánh giá không hợp lệ", e.getMessage());
        }
    }

    @Test
    public void testUpdateRating_InvalidRatingExceeds() {
        double newRating = 11.0;
        try {
            instance.updateRating(newRating);
            fail("Expected IllegalArgumentException for rating above 10");
        } catch (IllegalArgumentException e) {
            assertEquals("Điểm đánh giá không hợp lệ", e.getMessage());
        }
    }
}
